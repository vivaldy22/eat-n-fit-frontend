import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Navbar from "./utils/navbar";
import Home from "./page/home";
import About from "./page/about";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
function App() {
  return (
    <div className="App">
      <Navbar />
      <Route exact path="/" component={Home} />

      <Route path="/about" component={About} />

      {/* <Route path="/post" component={PostPage} />
      <Route path="/tags" component={TagsPage} />
      <Route path="/userByid/:id" component={UserByIdPage} />
      <Route path="/userPost/:id" component={PostUserPage} />
      <Route path="/comment/:id" component={CommentPage} />
      <Route path="/tagsPost/:id" component={TagsPost} /> */}
    </div>
  );
}

export default App;
