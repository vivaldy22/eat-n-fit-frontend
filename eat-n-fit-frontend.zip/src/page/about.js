import React, { Component } from "react";

class About extends Component {
  render() {
    return <div> ini halaman about</div>;
  }
}

export default About;
